% Load in patched files %

timer true;;

lisp `(load 'eval)`;;

loadt`conv`;;
