val quietdec = ref true;
val printDepth = ref 0;
val printLength = ref 0;

fun compile_theory () = ();
