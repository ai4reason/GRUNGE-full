[![Build Status](https://travis-ci.org/HOL-Theorem-Prover/HOL.svg?branch=master)](https://travis-ci.org/HOL-Theorem-Prover/HOL)

This is the distribution directory for the Kananaskis release of HOL4.
See http://hol-theorem-prover.org for online resources.

The following is a brief listing of what's available in the distribution.

     INSTALL        * Installation instructions
     COPYRIGHT      * Copyright notice
     std.prelude    * File loaded at the beginning of each HOL session

     bin/           * Executables
     doc/           * Some documentation, including release notes
     examples/      * Some examples
     help/          * Help support
     src/           * The system sources
     tools/         * Support for building the system
     sigobj/        * Collection of all signatures and compiled code
